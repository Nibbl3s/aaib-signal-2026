export const LAYERS = [
  "voice",
  "digital_actor",
  "narrative",
  "code",
  "world_art",
  "out_of_scope",
] as const;

export const EXPOSURES = [
  "ai_can_do_now",
  "ai_assisted_human_signs_off",
  "human_only",
] as const;

export type Layer = (typeof LAYERS)[number];
export type Exposure = (typeof EXPOSURES)[number];

