import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {parseOutput,classifyFailures} from './app-scoring';
const load=(p:string)=>JSON.parse(readFileSync(p,'utf8'));
const manifest=load('manifest.json');
assert.equal(readFileSync('exit-status','utf8').trim(),'0');
const events=readFileSync('calls.jsonl','utf8').trim().split('\n').map(l=>JSON.parse(l));
assert.equal(events.length,160);
const rows=manifest.schedule.map((s:any,i:number)=>{
  const [a,b]=events.slice(i*2,i*2+2);
  for(const [e,type] of [[a,'start'],[b,'end']]) {
    assert.equal(e.event,type); assert.equal(e.order,i+1);
    for(const k of ['id','pass','version']) assert.equal(e[k],s[k]);
  }
  const c=manifest.cases.find((c:any)=>c.id===s.id);
  const parsed=b.status==='response'?parseOutput(b.raw):null;
  const flags=parsed?classifyFailures(parsed,c.input,{layer:c.expectedLayer,exposure:c.expectedExposure},b.raw):[];
  const format=!!parsed?.formatValid;
  const layer=format&&parsed.layer===c.expectedLayer,exposure=format&&parsed.exposure===c.expectedExposure;
  let strictFormat=false;
  try {const o=JSON.parse(b.raw);strictFormat=format && Object.keys(o).sort().join(',')==='evidence,exposure,layer' && typeof o.evidence==='string';}catch{}
  const evidence=parsed?.evidence;
  return {...c,...b,startedAt:a.startedAt,elapsedMs:Date.parse(b.finishedAt)-Date.parse(a.startedAt),parsed,flags,format,layer,exposure,joint:layer&&exposure,
    evidenceNormalized:typeof evidence==='string'&&evidence.length>0&&!flags.includes('F2'),
    evidenceVerbatim:typeof evidence==='string'&&evidence.length>0&&(evidence==='none'||c.input.includes(evidence)),strictFormat};
});
const pairs=[];
for(const version of ['v1','v2'])for(const c of manifest.cases){
  const [a,b]=rows.filter((x:any)=>x.version===version&&x.id===c.id);
  assert.equal(a.pass,1);assert.equal(b.pass,2);
  const comparison= a.status!=='response'||b.status!=='response' ? 'request_unavailable'
    : a.format!==b.format ? 'parser_validity_disagreement' : !a.format ? 'both_parser_invalid'
    : a.parsed.layer!==b.parsed.layer||a.parsed.exposure!==b.parsed.exposure ? 'F6'
    : a.parsed.evidence!==b.parsed.evidence ? 'evidence_only'
    : a.raw!==b.raw ? 'raw_only' : 'identical';
  if(comparison==='F6'){a.flags.push('F6');b.flags.push('F6');}
  pairs.push({id:c.id,age:c.age,version,comparison,first:a.parsed,second:b.parsed});
}
const count=(a:any[],f:(x:any)=>boolean)=>a.filter(f).length;
const freq=(a:any[],f:(x:any)=>string)=>{const o:Record<string,number>={};for(const x of a){const k=f(x);o[k]=(o[k]??0)+1;}return o;};
const metrics=[];
const costs=[];
const sum=(r:any[],f:(x:any)=>number)=>r.reduce((s,x)=>s+f(x),0);
for(const version of ['v1','v2']){
  const all=rows.filter((r:any)=>r.version===version);
  for(const subset of ['old','new','full']){
    const rs=all.filter((r:any)=>subset==='full'||r.age===subset);
    const ps=pairs.filter(p=>p.version===version&&(subset==='full'||p.age===subset));
    const properties=['joint','layer','exposure','format','evidenceNormalized','evidenceVerbatim','strictFormat'];
    metrics.push({version,subset,n:rs.length,responses:count(rs,r=>r.status==='response'),...Object.fromEntries(properties.map(k=>[k,count(rs,r=>r[k])])),
      constant:count(rs,r=>r.expectedExposure==='ai_assisted_human_signs_off'),...Object.fromEntries(Array.from({length:6},(_,i)=>`F${i+1}`).map(k=>[k,count(rs,r=>r.flags.includes(k))])),pairs:freq(ps,p=>p.comparison)});
  }
  const byToken=all.filter((r:any)=>Number.isInteger(r.usage?.inputTokens)&&Number.isInteger(r.usage?.outputTokens));
  const withMeta=all.filter((r:any)=>r.providerMetadata?.gateway);
  const inputTokens=sum(byToken,r=>r.usage.inputTokens),outputTokens=sum(byToken,r=>r.usage.outputTokens);
  costs.push({version,calls:all.length,usageRecords:byToken.length,inputTokens,outputTokens,cacheRead:sum(byToken,r=>r.usage.inputTokenDetails?.cacheReadTokens??0),cacheWrite:sum(byToken,r=>r.usage.inputTokenDetails?.cacheWriteTokens??0),
    publicRateUsd:(inputTokens+outputTokens*5)/1e6,marketUsd:sum(withMeta.filter((x:any)=>x.providerMetadata.gateway.marketCost!=null),r=>Number(r.providerMetadata.gateway.marketCost)),marketRecords:count(withMeta,r=>r.providerMetadata.gateway.marketCost!=null),gatewayReportedUsd:sum(withMeta.filter((x:any)=>x.providerMetadata.gateway.cost!=null),r=>Number(r.providerMetadata.gateway.cost)),gatewayCostRecords:count(withMeta,r=>r.providerMetadata.gateway.cost!=null),providers:freq(withMeta,r=>r.providerMetadata.gateway.routing?.finalProvider??'unreported'),credentialTypes:freq(withMeta,r=>r.providerMetadata.gateway.routing?.modelAttempts?.flatMap((m:any)=>m.providerAttempts??[]).find((a:any)=>a.success)?.credentialType??'unreported'),modelIds:freq(all.filter((r:any)=>r.response),r=>r.response.modelId??'unreported'),finish:freq(all.filter((r:any)=>r.response),r=>`${r.finishReason} / ${r.rawFinishReason}`)});
}
const assisted='ai_assisted_human_signs_off';
const predictions=[['T02','code',assisted],['T03','code',assisted],['T04','code','human_only'],['T06','code',assisted],['T07','code','human_only'],['T14','code',assisted],['T15','out_of_scope',assisted],['T16','code',assisted],['T17','code','human_only'],['T18','digital_actor','human_only']].map(([id,layer,exposure])=>{
 const hits=rows.filter((r:any)=>r.version==='v2'&&r.id===id);
 return {id,layer,exposure,both:hits.every((r:any)=>r.format&&r.parsed.layer===layer&&r.parsed.exposure===exposure),actual:hits.map((r:any)=>r.parsed)};
});
const moves=manifest.schedule.filter((s:any)=>s.version==='v1').map((s:any)=>{
 const [a,b]=rows.filter((r:any)=>r.id===s.id&&r.pass===s.pass);
 return {id:s.id,age:a.age,pass:s.pass,move:a.joint?(b.joint?'both correct':'v1 only'):(b.joint?'v2 only':'neither')};
});
const results={metrics,costs,predictions,pairs,moves,movesSummary:freq(moves,m=>m.move),start:events[0].startedAt,end:events.at(-1).finishedAt};
writeFileSync('scored.json',JSON.stringify({results,rows},null,2)+'\n');
writeFileSync('summary.json',JSON.stringify(results,null,2)+'\n');
console.log(JSON.stringify({metrics,costs,moves:results.movesSummary}));
