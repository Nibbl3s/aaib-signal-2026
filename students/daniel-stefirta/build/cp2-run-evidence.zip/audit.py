import hashlib, json, re, collections
from pathlib import Path
p=Path('.')
load=lambda n: json.loads((p/n).read_text())
m=load('manifest.json')
a=load('scored.json')
events=[json.loads(l) for l in (p/'calls.jsonl').read_text().splitlines()]
assert len(events)==160
counts=collections.Counter()
for c,s,start,end,row in ((next(c for c in m['cases'] if c['id']==s['id']),s,events[2*i],events[2*i+1],a['rows'][i]) for i,s in enumerate(m['schedule'])):
    assert all(start[k]==end[k]==row[k]==v for k,v in s.items())
    assert start['startedAt']<=end['finishedAt']
    assert not any(k.lower() in {'headers','apikey','authorization','credentials'} for k in end)
    if end['status']!='response':
        assert not row['joint'] and not row['format']
        continue
    for k in ('status','raw','usage','response','finishReason','rawFinishReason'):
        assert row[k]==end[k]
    match=re.search(r'\{[\s\S]*\}',end['raw'])
    try: fields=json.loads(match[0]) if match else {}
    except ValueError: fields={}
    joint=(fields.get('layer'),fields.get('exposure'))==(c['expectedLayer'],c['expectedExposure'])
    assert joint==row['joint']
    for subset in ('full',c['age']):
        counts[(s['version'],subset,'joint')]+=joint
    counts[(s['version'],'usage','inputTokens')]+=end.get('usage',{}).get('inputTokens',0) or 0
    counts[(s['version'],'usage','outputTokens')]+=end.get('usage',{}).get('outputTokens',0) or 0
for b in a['results']['metrics']:
    assert counts[b['version'],b['subset'],'joint']==b['joint']
for b in a['results']['costs']:
    for token in ('inputTokens','outputTokens'):
        assert counts[b['version'],'usage',token]==b[token]
prompts=re.findall(r'^```\n([\s\S]*?)\n```$', (p/'proposed/prompt.md').read_text(),flags=re.M)
for row in events[::2]:
    c=next(c for c in m['cases'] if c['id']==row['id'])
    rendered=prompts[0 if row['version']=='v2' else 1].replace('{{input}}',c['input'])
    assert hashlib.sha256(rendered.encode()).hexdigest()==row['promptSha256']
print('Independent audit: 80 scheduled slots, logged prompt hashes, matched joint scores and token totals.')
