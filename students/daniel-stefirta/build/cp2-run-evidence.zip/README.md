# Strand Feasibility Analyzer: Checkpoint 2 run archive

- `manifest.json`: settings, frozen commit hashes, test IDs, and request order.
- `calls.jsonl`: ordered start and completion events; completion events include raw model replies or errors, SDK usage, finish reasons and credential-safe routing/cost metadata. Request headers and credentials are not saved. UTC timestamps.
- `scored.json`: per-call scores, parsed labels, comparisons and cost totals. `summary.json` contains just the aggregates and per-case repeat comparisons.
- `proposed/`: unchanged files from the two pre-run GitHub commits. The note that no inference has been made refers to the point when those commits were created. The two JSON receipts tie the files to GitHub.
- `score.ts` and `app-scoring.ts`: offline scoring and app parser/failure functions. `classifier-enums.ts` contains the original allowed enum sets, extracted for portability. To recompute scores, run `bun score.ts` from inside the archive. To check scores and rendered prompt hashes independently, run `python audit.py`.

No deploy or GitHub write was part of the inference run. Human review and correction timings are collected separately; this archive contains no fabricated review measurements or upstream invoice.
